#!/bin/sh
tmp=$PATH
export PATH=/opt/compiler/gcc-4.8.2/bin:$PATH
./lcov -d innobase.dir --rc geninfo_adjust_src_path="innobase.dir => ../../../../storage/innobase" -o test.info -c --rc lcov_branch_coverage=1
./genhtml -o result test.info --branch-coverage
export PATH=$tmp
